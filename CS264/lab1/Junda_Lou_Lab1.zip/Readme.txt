1. Open QtSpim
2. Click on "Reinitialize and Load file"
3. Choose 3 files one by one. (onePerLine.asm, singleSpace.asm, randomPerLine.asm)
4. Input 20 integers. One per line.
5. The program will automatic output the result when 20 integers are entered.
6. Close the program.