This is a personal planner for General Education.
It gives you a view of your GE classes that are either completed or not at any point.
If you plan to take some GEs next quarter, you can enroll it in the program to see what else you need to take.
If you are not satisfied with the schedule, you can drop it as well.

"status" command does not take any parameter.
"enroll" command command takes one parameter(one of GE areas such as A1) after a white space after the command.
"drop" command command takes one parameter(one of GE areas such as A1) after a white space after the command.
Case-Insensitive